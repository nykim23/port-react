import port01 from "../assets/img/port01.png";
// import port02 from "../assets/img/port02.jpg";
// import port03 from "../assets/img/port03.jpg";
// import port04 from "../assets/img/port04.jpg";
// import port05 from "../assets/img/port05.jpg";
// import port06 from "../assets/img/port06.jpg";
// import port07 from "../assets/img/port07.jpg";
// import port08 from "../assets/img/port08.jpg";
// import port09 from "../assets/img/port09.jpg";
// import port10 from "../assets/img/port10.jpg";





import SlideTop01 from "../assets/img/nyLogo2.png";
import SlideTop02 from "../assets/img/nyLogo3.png";
import SlideTop03 from "../assets/img/about.png";
import SlideTop04 from "../assets/img/zeplin.svg";
import SlideTop05 from "../assets/img/nyLogo.png";






export const introTopSlide = [
    {
        num:"01",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:SlideTop01,
        // icon:<GoGitBranch />
    },
    {
        num:"02",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:SlideTop02,
        // icon:<GoGitBranch />
    },
    {
        num:"03",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:SlideTop03,
        // icon:<GoGitBranch />
    },
    {
        num:"04",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:SlideTop04,
        // icon:<GoGitBranch />
    },
    {
        num:"05",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:SlideTop05,
        // icon:<GoGitBranch />
    },
]




export const headerNav = [
    {
        title:"intro",
        url:"#intro"
    },
    {
        title: "history",
        url: "#site"
    },
    {
        title: "portfolio",
        url: "#port"
    },
    {
        title: "skill",
        url: "#skill"
    },
    {
        title: "contact",
        url: "#contact"
    }
]


export const introText = {
    title:"port developer",
    desc:["Web", "Publisher","nykim"],
};

export const skillText = [
    {   
        title:"교보생명 FP소장 AI Assistance 고도화",
        desc:"교보생명 FP소장 AI Assistance 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2025년 04월 ~ 2025년 08월",
    },
    {   
        title:"신한카드 장기렌터카 반응형 구축",
        desc:"신한카드 장기렌터카 반응형 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2024년 09월 ~ 2025년 01월",
    },
    {   
        title:"두산그룹 FCM 내부 시스템",
        desc:"두산그룹 FCM 내부 시스템 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2024년 08월 ~ 2024년 08월",
    },
    {   
        title:"Next Allegro UI 개선 프로젝트",
        desc:"Next Allegro 반응형 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2024년 02월 ~ 2024년 06월",
    },
    {   
        title:"산업안전복지공단 반응형 홈페이지 구축",
        desc:"산업안전복지공단 반응형 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2023년 08월 ~ 2023년 11월",
    },
    {   
        title:"우리카드 챗봇 재구축",
        desc:"우리카드 챗봇 및 톡상담 재구축 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2023년 06월 ~ 2023년 07월",
    },
    {   
        title:"한화 컨버전스 태양광 모니터링 시스템 고도화",
        desc:"한화 컨버전스 태양광 모니터링 시스템 고도화 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2023년 04월 ~ 2023년 05월",
    },
    {   
        title:"SKT 모바일 지갑 UI 개선",
        desc:"모바일지갑, 국민비서 고도화 퍼블리싱, 서울시 전자 근로계약 포털 반응형 퍼블리싱 업무",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2022년 11월 ~ 2023년 01월",
    },
    {   
        title:"오스템 임플란트 공통 UI 개발",
        desc:"공통 UI 컴포넌트 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2022년 08월 ~ 2022년 10월",
    },
    {   
        title:"투썸 플레이스 모바일 고도화",
        desc:"투썸 플레이스 모바일 고도화 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2022년 02월 ~ 2022년 06월",
    },
    {   
        title:"한우리 열린 교육",
        desc:"한우리 열린 교육 개편 모바일 퍼블리싱, 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2021년 07월 ~ 2021년 11월",
    },
    {   
        title:"콜 투게더 화상회의 시스템 구축",
        desc:"콜 투게더 화상회의 시스템 구축 반응형 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2021년 01월 ~ 2021년 05월",
    },
    {   
        title:"CJ 올리브 네트웍스 그룹 평가보상",
        desc:"그룹 평가보상 개편 모바일 퍼블리싱, 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2020년 07월 ~ 2020년 11월",
    },
    {   
        title:"법무부 전자 공증 시스템",
        desc:"법무부 전자 공증 시스템 모바일 퍼블리싱, 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2020년 06월 ~ 2020년 07월",
    },
    {   
        title:"KAMCO 한국 자산 관리공사",
        desc:"온비드 재구축 프로젝트 모바일 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2020년 05월 ~ 2020년 06월",
    },
    {   
        title:"콜롬비아 보고타 FMS 센터(LG cns)",
        desc:"콜롬비아 보고타 FMS 센터 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2020년 03월 ~ 2020년 03월",
    },
    {   
        title:"레드 캡 투어",
        desc:"레드 캡 투어 웹 퍼블리싱, 모바일 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2019년 12월 ~ 2020년 02월",
    },
    {   
        title:"민주주의 서울",
        desc:"민주주의 서울 모바일 퍼블리싱, 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2019년 10월 ~ 2019년 12월",
    },
    {   
        title:"경찰청 국민제보",
        desc:"경찰청 국민제보 모바일 퍼블리싱, 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2019년 07월 ~ 2019년 09월",
    },
    {   
        title:"민주주의 서울",
        desc:"민주주의 서울 모바일 퍼블리싱, 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2019년 10월 ~ 2019년 12월",
    },
    {   
        title:"레드캡투어",
        desc:"레드캡투어 모바일, 웹 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2019년 05월 ~ 2019년 07월",
    },
    {   
        title:"mteletech",
        desc:"LG U+ 고객센터 웹표준 퍼블리싱, 본사 프로젝트 개발 퍼블리싱",
        work:"웹표준 마크업, HTML코딩, 웹퍼블리셔",
        date:"2019년 05월 ~ 2019년 07월",
    },
    {
        title:"..."
    }
    
]



export const siteText = [
    {
        text:["교보생명 FP소장 AI Assistance 고도화", "site compliant with", "webstandard"],
        title:"모바일 고도화 페이지 제작",
        date:"2025.04~2025.08",
        code:"https://github.com/",
        view:"https://github.com/",
        info:[
            "site coding",
            "production period: two days",
            "use stack:HTML5/CSS3, CSS Variable",
        ],
    },
    {
        text: ["신한카드 장기렌터카 반응형 구축", "site compliant with", "react.js"],
        title: "리액트를 이용한 사이트 제작",
        code: "http://github.com",
        view: "http://github.com",
        info: [
            "site coding",
            "production period : two days",
            "use stack : HTML5/CSS3, CSS Variable, Vite",
        ],
    },
    {
        text: ["두산그룹 FCM 내부 시스템", "site compliant with", "vue.js"],
        title: "뷰를 이용한 사이트 제작",
        code: "http://github.com",
        view: "http://github.com",
        info: [
            "site coding",
            "production period : two days",
            "use stack : HTML5/CSS3, Scss Variable, vue",
        ],
    },
    {
        text: ["Next Allegro UI 개선 프로젝트", "site compliant with", "next.js"],
        title: "넥스트를 이용한 사이트 제작",
        code: "http://github.com",
        view: "http://github.com",
        info: [
            "site coding",
            "production period : two days",
            "use stack : HTML5/CSS3, Scss Variable, next.js",
        ],
    },
    {
        text: ["산업안전복지공단 반응형 홈페이지 구축", "site compliant with", "next.js"],
        title: "넥스트를 이용한 사이트 제작",
        code: "http://github.com",
        view: "http://github.com",
        info: [
            "site coding",
            "production period : two days",
            "use stack : HTML5/CSS3, Scss Variable, next.js",
        ],
    },
    {
        text: ["한화 컨버전스 태양광 모니터링 시스템 고도화", "site compliant with", "next.js"],
        title: "한화 컨버전스 태양광 모니터링 시스템 고도화 퍼블리싱 업무",
        code: "http://github.com",
        view: "http://github.com",
        info: [
            "site coding",
            "production period : two days",
            "use stack : HTML5/CSS3, Scss Variable, next.js",
        ],
    },
]




export const portText = [
    {
        num:"01",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:port01,
        code:"http://github.com"
    },
    {
        num:"01",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:port01,
        code:"http://github.com"
    },
    {
        num:"01",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:port01,
        code:"http://github.com"
    },
    {
        num:"01",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:port01,
        code:"http://github.com"
    },
    {
        num:"01",
        title:"어워드에도 올라간 포트폴리오",
        desc:"라마",
        img:port01,
        code:"http://github.com"
    },
]




export const contactText = [
    // {
    //     link:"http://",
    //     title:"kk",
    // },
    {
        link:"mailto:sunchild23@naver.com",
        title:"mailto:",
        email:"sunchild23@naver.com",
    }
];





export const footerText = [
    {
        title:"youtube",
        desc:"유투브",
        link: "https://www.youtube.com"
    },
    {
        title:"github",
        desc:"유투브",
        link: "https://www.youtube.com"
    },
    {
        title:"gsap",
        desc:"유투브",
        link: "https://www.youtube.com"
    },
    {
        title:"react",
        desc:"유투브",
        link: "https://www.youtube.com"
    },
    {
        title:"vue",
        desc:"유투브",
        link: "https://www.youtube.com"
    },
    {
        title:"next",
        desc:"유투브",
        link: "https://www.youtube.com"
    },
]