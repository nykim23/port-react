import React from "react";

const Skip = () => {
    return (

        <div>1111</div>
        
    )
};

export default Skip;