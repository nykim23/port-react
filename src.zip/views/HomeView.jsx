import React from "react";
import Header from "../components/Header";
import Intro from "../components/Intro";
import Skill from "../components/Skill";
import Site from "../components/Site";
import Port from "../components/Port";
import Contact from "../components/Contact";
import Footer from "../components/Footer";
import Skip from "../components/Skip";
import Main from "../components/Main";
import AnimateTest from "../components/AnimateTest";

// import Animate from "../components/Animate";

const HomeView = () => {
    return (
        <>
            <Skip />
            <Header />
            <Main>
                {/* <Animate /> */}
                <Intro />
                <AnimateTest />
                <Site />
                <Port />
                <Skill />
                <Contact />
            </Main>
            <Footer />
        </>
    )
}

export default HomeView;